#!/usr/bin/env bash
set -euo pipefail

# Generate the native Android/iOS platform folders if this source-only project
# was unpacked without them.
if [ ! -d android ]; then
  flutter create --platforms=android .
fi

# Make the launcher label Arabic instead of the Dart/package name.
mkdir -p android/app/src/main/res/values
cat > android/app/src/main/res/values/strings.xml <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">حسبة</string>
</resources>
XML

python3 - <<'PY'
from pathlib import Path
p = Path('android/app/src/main/AndroidManifest.xml')
s = p.read_text(encoding='utf-8')
s = s.replace('android:label="${applicationName}"', 'android:label="@string/app_name"')
s = s.replace('android:label="hisba"', 'android:label="@string/app_name"')
p.write_text(s, encoding='utf-8')
PY

# Install dependencies before generating launcher icons.
flutter pub get

# Generate launcher icons from the supplied Hisba artwork.
dart run flutter_launcher_icons

echo "Android project prepared: app name = حسبة"
